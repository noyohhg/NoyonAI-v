# NoyonAI v1.2 — GitHub Actions APK build

This archive contains the original NoyonAI Android project plus a GitHub Actions workflow. The workflow builds a debug APK using Java 17, Gradle 8.7 and Android SDK 34. The original app source and existing files are otherwise unchanged.

## Build on GitHub
1. Create a **new repository** on https://github.com/new. Suggested name: `NoyonAI-v1.2`. Choose Public or Private as you prefer. Do not initialize it with a README, license, or .gitignore.
2. Extract this ZIP on your phone/computer.
3. Upload the contents of the extracted folder to the repository root. Make sure both `NoyonAI/` and `.github/` appear at the repository root (not inside an extra wrapper folder).
4. Open the repository's **Actions** tab. If prompted, enable GitHub Actions.
5. The workflow starts after files are pushed to the `main` branch. You can also open **Actions → Build NoyonAI APK → Run workflow**.
6. When the run finishes with a green check, open that run, scroll to **Artifacts**, and download `NoyonAI-v1.2-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Notes
- This produces a **debug APK**, not a Play Store release-signed APK.
- If GitHub rejects uploading many files through the browser, upload the extracted contents using GitHub Desktop or the Git command line instead.
- The app's existing source files were not intentionally modified; only this workflow and this guide were added.
