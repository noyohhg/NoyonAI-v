package com.priya.ai

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.*

object PriyaState {
    val running = MutableStateFlow(false)
    val status = MutableStateFlow("Tap to speak")
    val log = MutableStateFlow<List<String>>(emptyList())
    @Volatile var live: GeminiLive? = null
    fun addLog(s: String) { log.value = (log.value + s).takeLast(60) }
}

object Store {
    const val CAP = 30L * 1024 * 1024 // 30 MB memory cap
    private fun p(c: Context) = c.getSharedPreferences("priya", Context.MODE_PRIVATE)
    fun apiKey(c: Context) = p(c).getString("key", "")!!
    fun setApiKey(c: Context, v: String) = p(c).edit().putString("key", v.trim()).apply()
    fun model(c: Context) = p(c).getString("model", "gemini-3.1-flash-live-preview")!!
    fun setModel(c: Context, v: String) = p(c).edit().putString("model", v.trim()).apply()
    fun design(c: Context) = p(c).getInt("design", 0)
    fun setDesign(c: Context, v: Int) = p(c).edit().putInt("design", v).apply()
    fun always(c: Context) = p(c).getBoolean("always", false)
    fun setAlways(c: Context, v: Boolean) = p(c).edit().putBoolean("always", v).apply()

    private fun f(c: Context) = File(c.filesDir, "memory.txt")
    fun size(c: Context) = f(c).let { if (it.exists()) it.length() else 0L }
    fun clear(c: Context) { f(c).delete() }

    @Synchronized
    fun remember(c: Context, line: String) {
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val file = f(c)
        file.appendText("[$ts] ${line.replace("\n", " ")}\n")
        if (file.length() > CAP) trim(file)
    }

    private fun trim(file: File) {
        val keep = (CAP * 0.8).toLong()
        val rest = RandomAccessFile(file, "r").use { r ->
            r.seek(file.length() - keep); r.readLine()
            ByteArray((file.length() - r.filePointer).toInt()).also { r.readFully(it) }
        }
        file.writeBytes(rest)
    }

    fun recent(c: Context, max: Int = 20000): String {
        val file = f(c); if (!file.exists()) return ""
        return RandomAccessFile(file, "r").use { r ->
            val start = maxOf(0L, r.length() - max)
            r.seek(start)
            ByteArray((r.length() - start).toInt()).also { r.readFully(it) }.toString(Charsets.UTF_8)
        }
    }
}
