package com.priya.ai

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

@SuppressLint("MissingPermission")
class GeminiLive(private val ctx: Context) {
    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private val main = Handler(Looper.getMainLooper())
    private val playExec = Executors.newSingleThreadExecutor()
    private var ws: WebSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var am: AudioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    @Volatile private var ready = false
    @Volatile private var stopped = false
    private val uText = StringBuilder()
    private val pText = StringBuilder()

    private val toolsJson = """[{"functionDeclarations":[
      {"name":"open_app","description":"Phone me app kholo","parameters":{"type":"OBJECT","properties":{"app_name":{"type":"STRING"}},"required":["app_name"]}},
      {"name":"read_screen","description":"Abhi screen par jo likha hai wo padho"},
      {"name":"click_text","description":"Screen par is text wale button/item par tap karo","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
      {"name":"type_text","description":"Focused text box me text likho","parameters":{"type":"OBJECT","properties":{"text":{"type":"STRING"}},"required":["text"]}},
      {"name":"global_action","description":"home, back, recents, notifications ya lock","parameters":{"type":"OBJECT","properties":{"action":{"type":"STRING"}},"required":["action"]}},
      {"name":"scroll","description":"Screen scroll karo","parameters":{"type":"OBJECT","properties":{"direction":{"type":"STRING","description":"up ya down"}},"required":["direction"]}},
      {"name":"call_contact","description":"Contact ko call lagao","parameters":{"type":"OBJECT","properties":{"name":{"type":"STRING"}},"required":["name"]}},
      {"name":"play_youtube","description":"YouTube par gana/video search karke seedha play karo","parameters":{"type":"OBJECT","properties":{"query":{"type":"STRING","description":"gane ka naam aur artist"}},"required":["query"]}},
      {"name":"media_control","description":"Chalte gane/video ko pause, play, next ya previous karo","parameters":{"type":"OBJECT","properties":{"action":{"type":"STRING","description":"pause, play, next, previous"}},"required":["action"]}},
      {"name":"remember","description":"User ki koi zaroori baat hamesha yaad rakho","parameters":{"type":"OBJECT","properties":{"fact":{"type":"STRING"}},"required":["fact"]}}
    ]}]"""

    fun start() { stopped = false; am.mode = AudioManager.MODE_IN_COMMUNICATION; am.isSpeakerphoneOn = true; initTrack(); startMic(); connect() }

    fun stop() {
        stopped = true; ready = false
        ws?.close(1000, "bye"); ws = null
        rec?.run { try { stop() } catch (_: Exception) {}; release() }; rec = null
        track?.run { try { stop() } catch (_: Exception) {}; release() }; track = null
        am.mode = AudioManager.MODE_NORMAL; am.isSpeakerphoneOn = false
    }

    private fun connect() {
        val key = Store.apiKey(ctx)
        if (key.isBlank()) { PriyaState.status.value = "API key daalo (Menu)"; return }
        PriyaState.status.value = "Connecting…"
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) { w.send(setup().toString()) }
            override fun onMessage(w: WebSocket, text: String) = handle(text)
            override fun onMessage(w: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) { fail("Error: ${t.message?.take(40)}") }
            override fun onClosed(w: WebSocket, code: Int, reason: String) { fail("Reconnecting…") }
        })
    }

    private fun fail(msg: String) {
        ready = false
        if (stopped) return
        PriyaState.status.value = msg
        main.postDelayed({ if (!stopped) connect() }, 3000)
    }

    private fun setup(): JSONObject {
        val sys = "Tum Noyon AI ho, ek friendly, caring AI assistant. Hinglish me, chhote natural sentences me, " +
            "female voice me baat karo (feminine grammar: 'main kar rahi hoon'). Phone control ke liye tools use karo: " +
            "app kholna, screen padhna, tap karna, type karna, scroll, call. Gana ya video bajane ko kaha jaye to play_youtube tool use karo (wo khud search karke play bhi karta hai), pause/next ke liye media_control. Koi bhi zaroori baat user bataye to remember tool se save karo. " +
            "Purani yaaddasht (memory):\n" + Store.recent(ctx)
        val s = JSONObject("""{"generationConfig":{"responseModalities":["AUDIO"],"speechConfig":{"voiceConfig":{"prebuiltVoiceConfig":{"voiceName":"Aoede"}}}},"inputAudioTranscription":{},"outputAudioTranscription":{}}""")
        s.put("model", "models/" + Store.model(ctx))
        s.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
        s.put("tools", JSONArray(toolsJson))
        return JSONObject().put("setup", s)
    }

    private fun handle(msg: String) {
        val j = JSONObject(msg)
        if (j.has("setupComplete")) { ready = true; PriyaState.status.value = "Listening…" }
        j.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) { track?.run { pause(); flush(); play() } }
            sc.optJSONObject("inputTranscription")?.optString("text")?.let { uText.append(it) }
            sc.optJSONObject("outputTranscription")?.optString("text")?.let { pText.append(it) }
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { ps ->
                for (i in 0 until ps.length()) ps.getJSONObject(i).optJSONObject("inlineData")?.let {
                    val pcm = Base64.decode(it.getString("data"), Base64.DEFAULT)
                    PriyaState.status.value = "Noyon AI bol raha hai…"
                    playExec.execute { track?.write(pcm, 0, pcm.size) }
                }
            }
            if (sc.optBoolean("turnComplete")) {
                val u = uText.toString().trim(); val p = pText.toString().trim()
                if (u.isNotEmpty()) { Store.remember(ctx, "User: $u"); PriyaState.addLog("Tum: $u") }
                if (p.isNotEmpty()) { Store.remember(ctx, "Noyon AI: $p"); PriyaState.addLog("Noyon AI: $p") }
                uText.setLength(0); pText.setLength(0)
                PriyaState.status.value = "Listening…"
            }
        }
        j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { fc ->
            val out = JSONArray()
            for (i in 0 until fc.length()) {
                val c = fc.getJSONObject(i)
                val r = runTool(c.getString("name"), c.optJSONObject("args") ?: JSONObject())
                out.put(JSONObject().put("id", c.getString("id")).put("name", c.getString("name"))
                    .put("response", JSONObject().put("result", r)))
            }
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", out)).toString())
        }
    }

    private fun runTool(name: String, a: JSONObject): String = try {
        val acc = PriyaAccessibility.instance
        val noAcc = "Accessibility permission ON nahi hai"
        when (name) {
            "open_app" -> openApp(a.optString("app_name"))
            "read_screen" -> acc?.readScreen() ?: noAcc
            "click_text" -> acc?.clickText(a.optString("text")) ?: noAcc
            "type_text" -> acc?.typeText(a.optString("text")) ?: noAcc
            "global_action" -> acc?.global(a.optString("action")) ?: noAcc
            "scroll" -> acc?.scroll(a.optString("direction")) ?: noAcc
            "call_contact" -> callContact(a.optString("name"))
            "play_youtube" -> playYoutube(a.optString("query"))
            "media_control" -> mediaControl(a.optString("action"))
            "remember" -> { Store.remember(ctx, "FACT: " + a.optString("fact")); "saved" }
            else -> "unknown tool"
        }
    } catch (e: Exception) { "error: ${e.message}" }

    private fun playYoutube(q: String): String {
        val acc = PriyaAccessibility.instance ?: return "Accessibility permission ON nahi hai"
        val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        am.mode = AudioManager.MODE_NORMAL // gana poori awaaz me bajne ke liye
        Thread.sleep(3500)
        repeat(10) { if (acc.clickFirstVideo()) return "'$q' play ho raha hai" ; Thread.sleep(800) }
        acc.tapFallback()
        return "'$q' search ho gaya, pehle result par tap kiya"
    }

    private fun mediaControl(a: String): String {
        val code = when (a) { "pause" -> android.view.KeyEvent.KEYCODE_MEDIA_PAUSE; "play" -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY
            "next" -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS; else -> return "unknown" }
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code))
        return "done"
    }

    private fun openApp(n: String): String {
        val pm = ctx.packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val m = pm.queryIntentActivities(li, 0).firstOrNull { it.loadLabel(pm).toString().contains(n, true) } ?: return "app nahi mila"
        ctx.startActivity(Intent(li).setClassName(m.activityInfo.packageName, m.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "opened ${m.loadLabel(pm)}"
    }

    private fun callContact(n: String): String {
        val c = ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$n%"), null)
        val num = c?.use { if (it.moveToFirst()) it.getString(0) else null } ?: return "contact nahi mila"
        ctx.startActivity(Intent(Intent.ACTION_CALL, android.net.Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "calling $n"
    }

    private fun initTrack() {
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) * 4)
            .setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
    }

    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400))
        // Echo cancellation: Noyon AI apni hi awaaz nahi sunega
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.enabled = true
        rec = r; r.startRecording()
        Thread {
            val buf = ByteArray(3200)
            while (!stopped) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0 && ready) {
                    val d = Base64.encodeToString(buf, 0, n, Base64.NO_WRAP)
                    ws?.send("""{"realtimeInput":{"audio":{"data":"$d","mimeType":"audio/pcm;rate=16000"}}}""")
                }
            }
        }.start()
    }

    fun sendText(t: String) {
        PriyaState.addLog("Tum: $t"); Store.remember(ctx, "User(text): $t")
        ws?.send(JSONObject().put("realtimeInput", JSONObject().put("text", t)).toString())
    }

    fun sendImage(jpeg: ByteArray) {
        val d = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        ws?.send("""{"realtimeInput":{"video":{"data":"$d","mimeType":"image/jpeg"}}}""")
    }
}
