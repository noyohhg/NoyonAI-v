package com.priya.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream

private val BG = Color(0xFF0B0F1A)
private val BLUE = Color(0xFF2F6BFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = BLUE)) { App() } }
    }
}

private fun hasP(c: android.content.Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

private fun startPriya(c: android.content.Context) {
    if (Store.apiKey(c).isBlank()) { Toast.makeText(c, "Pehle Menu > Gemini API Key daalo", Toast.LENGTH_LONG).show(); return }
    ContextCompat.startForegroundService(c, Intent(c, PriyaService::class.java))
}
private fun stopPriya(c: android.content.Context) { c.startService(Intent(c, PriyaService::class.java).setAction("STOP")) }

@Composable
fun App() {
    val ctx = LocalContext.current
    var design by remember { mutableIntStateOf(Store.design(ctx)) }
    var page by remember { mutableStateOf("home") }
    var menu by remember { mutableStateOf(false) }
    var chat by remember { mutableStateOf(false) }
    var always by remember { mutableStateOf(Store.always(ctx)) }
    val running by PriyaState.running.collectAsState()
    val status by PriyaState.status.collectAsState()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) startPriya(ctx) }
    val camPhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { b: Bitmap? ->
        if (b != null) { val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 80, o); PriyaState.live?.sendImage(o.toByteArray()) }
    }
    val camPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) camPhoto.launch(null) }

    fun toggleMic() {
        if (running) stopPriya(ctx)
        else if (!hasP(ctx, Manifest.permission.RECORD_AUDIO)) micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        else startPriya(ctx)
    }
    LaunchedEffect(Unit) {
        if (always && !running && hasP(ctx, Manifest.permission.RECORD_AUDIO) && Store.apiKey(ctx).isNotBlank()) startPriya(ctx)
    }
    BackHandler(page != "home") { page = "home" }

    when (page) {
        "perm" -> PermPage { page = "home" }
        "key" -> KeyPage { page = "home" }
        "mem" -> MemPage { page = "home" }
        else -> {
            val bgs = listOf(R.drawable.ui_1, R.drawable.ui_2, R.drawable.ui_3)
            BoxWithConstraints(Modifier.fillMaxSize().background(BG)) {
                Image(painterResource(bgs[design]), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                val w = maxWidth; val h = maxHeight
                // Screenshot ke buttons ke upar invisible tap-areas (720x1640 layout)
                @Composable fun Spot(cx: Float, cy: Float, rf: Float, onClick: () -> Unit) {
                    val r = w * rf
                    Box(Modifier.offset(w * cx - r, h * cy - r).size(r * 2).clip(CircleShape).clickable(onClick = onClick))
                }
                Spot(0.114f, 0.084f, 0.07f) { menu = true }
                Spot(0.286f, 0.862f, 0.065f) {
                    if (hasP(ctx, Manifest.permission.CAMERA)) camPhoto.launch(null) else camPerm.launch(Manifest.permission.CAMERA)
                }
                Spot(0.5f, 0.862f, 0.105f) { toggleMic() }
                Spot(0.714f, 0.862f, 0.065f) { chat = true }
                if (running) {
                    val r = w * 0.105f
                    Box(Modifier.offset(w * 0.5f - r, h * 0.862f - r).size(r * 2).border(3.dp, Color(0xFF3DFF8F), CircleShape))
                    Text(status, Modifier.align(Alignment.BottomCenter).padding(bottom = h * 0.17f)
                        .background(Color(0x99000000), RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 6.dp),
                        color = Color.White, fontSize = 14.sp)
                }
            }
        }
    }

    if (menu) AlertDialog(onDismissRequest = { menu = false }, confirmButton = { TextButton({ menu = false }) { Text("Close") } },
        title = { Text("Noyon AI Menu") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("UI Design", color = Color.Gray)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (i in 0..2) FilterChip(design == i, { design = i; Store.setDesign(ctx, i) }, { Text("Design ${i + 1}") })
                }
                Divider()
                TextButton({ menu = false; page = "perm" }) { Text("Permissions") }
                TextButton({ menu = false; page = "key" }) { Text("Gemini API Key") }
                TextButton({ menu = false; page = "mem" }) { Text("Memory (30 MB)") }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("App khulte hi Always Listening", Modifier.weight(1f))
                    Switch(always, { always = it; Store.setAlways(ctx, it) })
                }
            }
        })

    if (chat) ChatDialog { chat = false }
}

@Composable
fun ChatDialog(close: () -> Unit) {
    val log by PriyaState.log.collectAsState()
    var t by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, confirmButton = { TextButton(close) { Text("Close") } }, title = { Text("Chat") }, text = {
        Column {
            LazyColumn(Modifier.heightIn(max = 300.dp)) { items(log) { Text(it, Modifier.padding(vertical = 3.dp), fontSize = 14.sp) } }
            OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth(), placeholder = { Text("Noyon AI-কে লিখো…") },
                trailingIcon = { TextButton({ if (t.isNotBlank()) { PriyaState.live?.sendText(t); t = "" } }) { Text("Send") } })
            if (!PriyaState.running.value) Text("প্রথমে মাইকে চাপ দিয়ে Noyon AI চালু করো", color = Color.Gray, fontSize = 12.sp)
        }
    })
}

private class Perm(val name: String, val why: String, val ok: Boolean, val go: () -> Unit)

@Composable
fun PermPage(back: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(700); tick++ } }
    var req by remember { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    fun rt(p: String) = { launcher.launch(p) }
    fun open(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    val pkg = Uri.parse("package:${ctx.packageName}")
    val t = tick
    val list = listOf(
        Perm("Microphone", "Noyon AI-এর সঙ্গে voice-এ কথা বলার জন্য", hasP(ctx, Manifest.permission.RECORD_AUDIO), rt(Manifest.permission.RECORD_AUDIO)),
        Perm("Accessibility", "Phone control, apps kholna, screen padhna",
            Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(ctx.packageName) == true,
            { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }),
        Perm("Display over other apps", "Background se apps kholne ke liye", Settings.canDrawOverlays(ctx),
            { open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) }),
        Perm("Battery optimization OFF", "Background me hamesha listening",
            (ctx.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName),
            { open(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)) }),
        Perm("Notifications", "Listening notification dikhane ke liye",
            Build.VERSION.SDK_INT < 33 || hasP(ctx, Manifest.permission.POST_NOTIFICATIONS),
            rt(Manifest.permission.POST_NOTIFICATIONS)),
        Perm("Camera", "ছবি দেখিয়ে Noyon AI-কে প্রশ্ন করার জন্য", hasP(ctx, Manifest.permission.CAMERA), rt(Manifest.permission.CAMERA)),
        Perm("Contacts", "Naam se contact dhoondhne ke liye", hasP(ctx, Manifest.permission.READ_CONTACTS), rt(Manifest.permission.READ_CONTACTS)),
        Perm("Phone calls", "Noyon AI-কে কল করতে বলার জন্য", hasP(ctx, Manifest.permission.CALL_PHONE), rt(Manifest.permission.CALL_PHONE)),
    )
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { TextButton(back) { Text("←") }; Text("Permissions", fontSize = 22.sp, color = Color.White) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { p ->
                Row(Modifier.fillMaxWidth().background(Color(0xFF151B2B), RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(p.name, color = Color.White); Text(p.why, color = Color.Gray, fontSize = 12.sp) }
                    if (p.ok) Text("✓ ON", color = Color(0xFF3DFF8F)) else Button(p.go) { Text("Allow") }
                }
            }
        }
    }
}

@Composable
fun KeyPage(back: () -> Unit) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Store.apiKey(ctx)) }
    var model by remember { mutableStateOf(Store.model(ctx)) }
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { TextButton(back) { Text("←") }; Text("Gemini API Key", fontSize = 22.sp, color = Color.White) }
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API Key") }, singleLine = true,
            visualTransformation = if (show) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation())
        TextButton({ show = !show }) { Text(if (show) "Hide" else "Show") }
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Live model") }, singleLine = true)
        Text("Key aistudio.google.com se milegi. Phone me hi save hoti hai.", color = Color.Gray, fontSize = 12.sp)
        Button({ Store.setApiKey(ctx, key); Store.setModel(ctx, model); Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show(); back() }, Modifier.fillMaxWidth()) { Text("Save") }
    }
}

@Composable
fun MemPage(back: () -> Unit) {
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val used = remember(refresh) { Store.size(ctx) }
    val text = remember(refresh) { Store.recent(ctx, 4000) }
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { TextButton(back) { Text("←") }; Text("Memory", fontSize = 22.sp, color = Color.White) }
        Text("%.2f MB / 30 MB use hua".format(used / 1048576.0), color = Color.White)
        LinearProgressIndicator(progress = { (used.toFloat() / Store.CAP).coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
        Text("Pichli baatein:", color = Color.Gray)
        Text(text.ifBlank { "Abhi kuch save nahi hai" }, Modifier.weight(1f).verticalScroll(rememberScrollState()), color = Color.White, fontSize = 13.sp)
        OutlinedButton({ Store.clear(ctx); refresh++ }, Modifier.fillMaxWidth()) { Text("Memory clear karo") }
    }
}
