# Termux me build
1. `pkg install unzip && unzip NoyonAI_v1.2.zip && cd NoyonAI`
2. `termux-setup-storage`  (APK Downloads me copy hone ke liye)
3. `bash setup_termux.sh`  (ek baar)
4. `bash build.sh`
APK: /sdcard/Download/NoyonAI_v1.2.apk
Note: Termux me ARM Android SDK (platform 34, build-tools) alag se chahiye; official SDK x86 hai.
